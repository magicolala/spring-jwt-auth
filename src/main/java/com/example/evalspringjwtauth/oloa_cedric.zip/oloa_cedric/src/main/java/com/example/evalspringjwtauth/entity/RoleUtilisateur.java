package com.example.evalspringjwtauth.entity;

public enum RoleUtilisateur {
    ADMIN, USER
}
