package com.example.springbasicauth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBasicAuthApplicationTests {

    @Test
    void contextLoads() {
    }

}
