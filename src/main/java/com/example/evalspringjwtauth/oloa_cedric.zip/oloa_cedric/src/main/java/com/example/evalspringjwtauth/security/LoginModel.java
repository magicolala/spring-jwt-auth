package com.example.evalspringjwtauth.security;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LoginModel {

    private String username;
    private String password;

}
