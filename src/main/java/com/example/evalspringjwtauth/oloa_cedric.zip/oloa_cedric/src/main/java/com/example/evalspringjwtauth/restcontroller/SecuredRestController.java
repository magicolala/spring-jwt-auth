package com.example.evalspringjwtauth.restcontroller;

import com.example.evalspringjwtauth.entity.RoleUtilisateur;
import com.example.evalspringjwtauth.entity.Utilisateur;
import com.example.evalspringjwtauth.repository.UtilisateurRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api")
public class SecuredRestController {

    private final UtilisateurRepository utilisateurRepository;

    @GetMapping("/all")
    public String everyoneEndpoint() {
        return "Tout le monde a acc�s";

    }

    @GetMapping("/secured")
    public String securedEndpoint() {
        return "User S�curis�";
    }

    @GetMapping("/secured/admin")
    public String adminEndPoint() {
        return "Admin s�curis�";
    }


    // Pour s'enregister en tant que utilisateur
    @PostMapping("/register")
    public ResponseEntity<Utilisateur> register(@RequestBody Utilisateur utilisateur) {

        try {
            utilisateur.setRole(RoleUtilisateur.USER);
            Utilisateur _utilisateur = utilisateurRepository.save(utilisateur);

            return new ResponseEntity<>(_utilisateur, HttpStatus.CREATED);

        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

}
