package com.example.evalspringjwtauth.security;

import com.example.evalspringjwtauth.repository.UtilisateurRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class DBInit implements CommandLineRunner {

    private final UtilisateurRepository utilisateurRepository;
    private final PasswordEncoder       passwordEncoder;

    @Override
    public void run(String... args) throws Exception {
//		utilisateurRepository.save(new Utilisateur("Div", passwordEncoder.encode("123"), RoleUtilisateur.ADMIN));
//		utilisateurRepository.save(new Utilisateur("Cris", passwordEncoder.encode("1234"), RoleUtilisateur.USER));
    }

}
